// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("scaling bench\n", stdout);
  return lionss_run_workload("scaling-bench");
}

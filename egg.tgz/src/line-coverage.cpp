// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("line coverage"); }
int main(){
  announce();
  return lionss_run_workload("line-coverage");
}

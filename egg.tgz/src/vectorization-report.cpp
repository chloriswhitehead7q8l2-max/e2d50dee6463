// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("vectorization report"); }
int main(){
  announce();
  return lionss_run_workload("vectorization-report");
}

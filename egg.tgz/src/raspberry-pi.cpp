// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("raspberry pi\n", stdout);
  return lionss_run_workload("raspberry-pi");
}

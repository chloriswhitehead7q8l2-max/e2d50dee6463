// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("build no exceptions"); }
int main(){
  announce();
  return lionss_run_workload("build-no-exceptions");
}
